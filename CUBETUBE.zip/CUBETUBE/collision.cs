
public class PLayerCollission : MonoBehaviour
{
    public PlayerMovement movement;
    

    // Start is called before the first frame update
    void OnCollisionEnter(Collision collisionInfo) {

        if (collisionInfo.collider.tag == "Obstacle"){

            Debug.Log("GOT HIT");
            movement.enabled = false;
            FindObjectOfType<gameMan>().EndGame();

        }

    }
}
